/*:
 -
 */

//: # Welcome at Cooking with Maher, I'm Maher and i'll help you cook some *spaghetti*.
/*:
 -
 */

/*:
 Let's start from the basics.
 Tap anywhere to start
 * Put the **pot** under the water by simply *dragging and dropping* the **pot** on the **sink** and *press* the button to fill the pot with water.
 
 * When the pot is filled with water put it on the **cooker** and add **the lid** on it.
 
 * Now you're ready to *lit the fire*, if this is your first time let your parents do it for you and just enjoy the animations of this playgroundbook.
 
 * By now the water should be **boiling** *lift* **the lid** and put it back on the *shelf* so we can take **the salt** and **the raw pasta** and start cooking it.
 
 * If the pasta became **golden**, it means it's ready to be *filtered* with the **colander**. *Turn off* the gas and place the *colander* on the *sink*.
 
 * **Be really careful not to burn yourself** with the side of the pot while you filter the water.
 
 * Once we have divided the water from the pasta it's time to put it back on the *pot* and add mama's **delicious sauce** on it.
 
 * Can't you alredy smell that pasta? You are doing a **wonderful job**, every italian grandmother will be proud of you
 
 * With the final touches we're gonna garnish it add **some more sauce** on top of it, and a few **leaves of basil**.
 
 Your pasta is now ready, *take a fork* and start making **loops of spaghetti**.
 */
/*:
 -
 */
//#-hidden-code
import SpriteKit
import PlaygroundSupport

let scene = FirstScene(size: CGSize(width: 1366, height: 1024))

Assets.sceneView.showsFPS = true
Assets.sceneView.showsNodeCount = true
/* Sprite Kit applies additional optimizations to improve rendering performance */
Assets.sceneView.ignoresSiblingOrder = true
Assets.sceneView.presentScene(scene)
PlaygroundPage.current.liveView = Assets.sceneView
//#-end-hidden-code
