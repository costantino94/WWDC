import SpriteKit
import PlaygroundSupport

public class GameScene: SKScene {
    var touchLocation = CGPoint()
    var gameState: GameState = .pot
    
    public override init(size: CGSize) {
        super.init(size: size)
        
        scaleMode = .aspectFit
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("")
    }
    
    func tomato () {
        //        used if conditions to determinate the state of the game to let just the right object be clickable on a determinated state
        if (Assets.pan.contains(touchLocation) && gameState == .tomato) {
            //            drag and drop lines
            Assets.pan.position.x = touchLocation.x
            Assets.pan.position.y = touchLocation.y
            //            locking objects in the correct position
            if (Assets.pan.position.y < 600.0 && Assets.pan.position.x < 300 && Assets.pan.position.x > 100) {
                Assets.pan2.position.x = 196
                Assets.pan2.position.y = 624
                Assets.pan2.addChild(Assets.sauce)
                Assets.pan.removeFromParent()
                Assets.pan2.isHidden = false
                Assets.littleLid.isHidden = false
                Assets.pan2.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                Assets.sauce.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                Assets.pasta1.run(SKAction.colorize(with: .red, colorBlendFactor: 0.2, duration: 3))
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.3, execute: {
                    self.addChild(Assets.sauceAudio)
                })
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                    Assets.pan2.run(SKAction.rotate(toAngle: 0, duration: 0.1))
                    Assets.sauce.removeFromParent()
                    Assets.pan2.position.x = 491
                    Assets.pan2.position.y = 360
                    Assets.sauceAudio.removeFromParent()
                    
                })
                gameState = .end
            }
        }
    }
    func drainWater2(){
        if (Assets.colander.contains(touchLocation) && gameState == .drainWater2) {
            Assets.colander.position.x = touchLocation.x
            Assets.colander.position.y = touchLocation.y
            Assets.pasta1.position.x = touchLocation.x
            Assets.pasta1.position.y = touchLocation.y
            
            if (Assets.colander.position.y < 600.0 && Assets.colander.position.x < 300 && Assets.colander.position.x > 100) {
                Assets.pasta1.position.x = 200
                Assets.pasta1.position.y = 628
                Assets.colander.position.x = 196
                Assets.colander.position.y = 624
                
                Assets.colander.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                Assets.pasta1.run(SKAction.move(to: CGPoint(x: 190, y: 370), duration: 2))
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.1, execute: {
                    Assets.colander.run(SKAction.rotate(toAngle: 0, duration: 0.1))
                    Assets.colander.position.x = 200
                    Assets.colander.position.y = 954
                })
                gameState = .tomato
            }
        }
    }
//    lid animation
    func removeLid (){
        if (gameState == .animation)
        {
            let left = SKAction.rotate(toAngle: 0.1, duration: 0.1)
            let right = SKAction.rotate(toAngle: -0.1, duration: 0.1)
            let action = SKAction.sequence([left, right])
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
                if (self.gameState == .animation){
            Assets.lid.run(SKAction.repeatForever(action))
                }
            })
            if (Assets.lid.contains(touchLocation))
            {
                gameState = .removeLid
            }
        }
    }
    func turnOffFire (){
        if Assets.miniButton.contains(touchLocation) && gameState == .turnOffFire {
            Assets.miniButton.run(SKAction.rotate(toAngle: 0, duration: 0.5))
            Assets.fire.removeFromParent()
            Assets.bubbles.removeFromParent()
            Assets.waterBoilingAudio.removeFromParent()
            Assets.waterBoilingAudio2.removeFromParent()
            
            gameState = .colander
        }
    }
    
    func stopLid() {
        //        removing animations from lid when not used
        if (Assets.lid.contains(touchLocation) && gameState == .removeLid) {
            Assets.lid.removeAllActions()
        }
    }
    
    func boiling () {
        if (Assets.lid.contains(touchLocation) && gameState == .removeLid) {
            Assets.lid.position.x = touchLocation.x
            Assets.lid.position.y = touchLocation.y
            Assets.lid.removeAllActions()
            if (Assets.lid.position.y > 600.0 && Assets.lid.position.x < 1300 && Assets.lid.position.x > 800) {
                Assets.lid.position.x = 800
                Assets.lid.position.y = 800
                Assets.lid.run(SKAction.rotate(toAngle: 0, duration: 0))
                addChild(Assets.potOnIronAudio)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2, execute: {
                    Assets.potOnIronAudio.removeFromParent()
                })
                gameState = .salt
            }
        }
    }
    func drainWater () {
        if (Assets.pot.contains(touchLocation) && gameState == .drainWater) {
            Assets.pot.position.x = touchLocation.x
            Assets.pot.position.y = touchLocation.y
            Assets.pasta1.position.x = touchLocation.x
            Assets.pasta1.position.y = touchLocation.y
            Assets.bubbles.position.x = touchLocation.x
            Assets.bubbles.position.y = touchLocation.y
            if (Assets.pot.position.y > 300 && Assets.pot.position.x < 1300 && Assets.pot.position.x > 800) {
                Assets.pasta1.position.x = 920
                Assets.pasta1.position.y = 624
                Assets.pot.position.x = 920
                Assets.pot.position.y = 624
                Assets.pot.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                Assets.explotionEmitter.isHidden = false
                Assets.pasta1.addChild(Assets.steam)
                addChild(Assets.drainingWaterAudio)
                Assets.pasta1.run(SKAction.move(to: CGPoint(x: 920, y: 370), duration: 2))
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5, execute: {
                    Assets.pot.texture = SKTexture(imageNamed: "water2")
                })
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.1, execute: {
                    Assets.pot.texture = SKTexture(imageNamed: "water1")
                })
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                    Assets.pot.run(SKAction.rotate(toAngle: 0, duration: 0.1))
                    Assets.drainingWaterAudio.removeFromParent()
                    Assets.explotionEmitter.removeFromParent()
                    Assets.steam.removeFromParent()
                    Assets.pot.texture = SKTexture(imageNamed: "pot")
                })
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.5, execute: {
                    Assets.pot.position.x = 196
                    Assets.pot.position.y = 380
                })
                gameState = .drainWater2
            }
        }
    }
    
    
    
    func addPasta() {
        if (Assets.pasta.contains(touchLocation) && gameState == .pasta) {
            Assets.pasta.position.x = touchLocation.x
            Assets.pasta.position.y = touchLocation.y
            if (Assets.pasta.position.y < 400.0 && Assets.pasta.position.x < 300 && Assets.pasta.position.x > 100) {
                Assets.pasta.position.x = 192
                Assets.pasta.position.y = 414
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                    //                    animating pasta
                    Assets.pasta1.isHidden = false
                    Assets.pasta.removeFromParent()
                    
                })
                
                
                
                
                
                gameState = .turnOffFire
                
            }
        }
    }
    
    func addSalt() {
        if (Assets.salt.contains(touchLocation) && gameState == .salt) {
            (Assets.salt.position.x = touchLocation.x)
            (Assets.salt.position.y = touchLocation.y)
            if (Assets.salt.position.y < 500.0 && Assets.salt.position.x < 300 && Assets.salt.position.x > 100) {
                
                Assets.salt.position.x = 179
                Assets.salt.position.y = 489
                Assets.saltParticle.isHidden = false
                addChild(Assets.saltAudio)
                
                Assets.salt.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                Assets.saltParticle.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.8, execute: {
                    Assets.salt.run(SKAction.rotate(toAngle: 0, duration: 0.1))
                    Assets.salt.position.x = 159
                    Assets.salt.position.y = 729
                    Assets.saltParticle.removeFromParent()
                    Assets.saltAudio.removeFromParent()
                })
                
                Assets.potWW.texture = SKTexture(imageNamed: "saltedWater")
                
                
                gameState = .pasta
                
            }
            
        }
    }
    
    func addWater() {
        
        if Assets.button.contains(touchLocation) && gameState == .water {
            
            Assets.water.addChild(Assets.waterSinkAudio)
            Assets.water.isHidden = false
            //            animating pot filling
            Assets.pot.texture = SKTexture(imageNamed: "water1")
            (gameState = .potWW)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                ( Assets.pot.texture = SKTexture(imageNamed: "water2"))
            })
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3, execute: {
                Assets.pot.texture = SKTexture(imageNamed: "water3")
                (Assets.water.removeFromParent())
                Assets.button.texture = SKTexture(imageNamed: "waterButton")
                Assets.pot.texture = SKTexture(imageNamed: "potW")
                
                
            })
            
        }
    }
    
    func litFire() {
        if Assets.miniButton.contains(touchLocation) && gameState == .litFire  {
            addChild(Assets.litFireAudio)
            Assets.miniButton.run(SKAction.rotate(toAngle: -CGFloat.pi / 2, duration: 0.5))
            addChild(Assets.waterBoilingAudio)
            Assets.fire.isHidden = false
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
                self.addChild(Assets.waterBoilingAudio2)
            
            
            Assets.bubbles.isHidden = false
            
            let up = SKAction.move(by: CGVector(dx: 0, dy: 15),duration: 0.4)
            let down = SKAction.move(by: CGVector(dx: 0, dy: -15),duration: 0.4)
            let action = SKAction.sequence([up,down])
            
            Assets.bubbles.run(SKAction.repeatForever(action))
            })
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5, execute: {
                
                Assets.litFireAudio.removeFromParent()
                
                
            })
            
            gameState = .animation
            
        }
    }
    
    func moveObjects() {
        
        if Assets.pot.contains(touchLocation) && gameState == .pot {
            Assets.pot.position.x = touchLocation.x
            Assets.pot.position.y = touchLocation.y
            if (Assets.pot.position.y < 400.0 && Assets.pot.position.x < 1100 && Assets.pot.position.x > 880) {
                Assets.pot.position.x = 920
                Assets.pot.position.y = 385
                addChild(Assets.potOnIronAudio)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2, execute: {
                    Assets.potOnIronAudio.removeFromParent()
                })
                gameState = .water
                
            }
        }
        else if Assets.lid.contains(touchLocation) && gameState == .lid {
            Assets.lid.position.x = touchLocation.x
            Assets.lid.position.y = touchLocation.y
            if (Assets.lid.position.y < 600.0 && Assets.lid.position.x < 230 && Assets.lid.position.x > 180){
                Assets.lid.position.x = 196
                Assets.lid.position.y = 477
                addChild(Assets.potOnIronAudio)
                Assets.lid.texture = SKTexture(imageNamed: "lid")
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2, execute: {
                    Assets.potOnIronAudio.removeFromParent()
                })
                gameState = .litFire
            }
        }
        else if Assets.pot.contains(touchLocation) && gameState == .potWW {
            Assets.pot.position.x = touchLocation.x
            Assets.pot.position.y = touchLocation.y
            if (Assets.pot.position.y < 600.0 && Assets.pot.position.x < 300 && Assets.pot.position.x > 100){
                Assets.pot.position.x = 196
                Assets.pot.position.y = 371
                addChild(Assets.potOnIronAudio)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2, execute: {
                    Assets.potOnIronAudio.removeFromParent()
                })
                gameState = .lid
            }
        }
        else if Assets.potWW.contains(touchLocation) && gameState == .litFire {
            Assets.potWW.position.x = touchLocation.x
            Assets.potWW.position.y = touchLocation.y
            if (Assets.potWW.position.y < 500.0 && Assets.potWW.position.x < 450 && Assets.potWW.position.x > 130){
                Assets.potWW.position.x = 230
                Assets.potWW.position.y = 420
                gameState = .boiling
            }
        }
        else if (Assets.colander.contains(touchLocation) && gameState == .colander) {
            Assets.colander.position.x = touchLocation.x
            Assets.colander.position.y = touchLocation.y
            if (Assets.colander.position.y < 400.0 && Assets.colander.position.x < 1000 && Assets.colander.position.x > 880) {
                Assets.colander.position.x = 920
                Assets.colander.position.y = 385
                addChild(Assets.potOnIronAudio)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.2, execute: {
                    Assets.potOnIronAudio.removeFromParent()
                })
                gameState = .drainWater
                
            }
        }
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            touchLocation = touch.location(in: self)
            addPasta()
            addSalt()
            stopLid()
            goToScene()
            addWater()
            litFire()
            turnOffFire()
            removeLid()
            light()
        }
    }
    
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            touchLocation = touch.location(in: self)
            moveObjects()
            addSalt()
            litFire()
            addPasta()
            drainWater()
            removeLid()
            drainWater2()
            tomato()
            boiling()
            light()
        }
    }
    func light(){
        if (gameState == .pot){
            Assets.pot.texture = SKTexture(imageNamed: "pot1")
        }
        else if gameState == .water {
            Assets.button.texture = SKTexture(imageNamed: "waterButton1")
            Assets.pot.texture = SKTexture(imageNamed: "pot")
        }
        else if (gameState == .lid) {
            Assets.button.texture = SKTexture(imageNamed: "waterButton")
            Assets.lid.texture = SKTexture(imageNamed: "lid1")
            
        }
        else if (gameState == .litFire) {
            Assets.miniButton.texture = SKTexture(imageNamed: "minibutton1")
            Assets.lid.texture = SKTexture(imageNamed: "lid")
        }
        else if (gameState == .animation) {
            Assets.miniButton.texture = SKTexture(imageNamed: "minibutton")
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
            Assets.lid.texture = SKTexture(imageNamed: "lid1")
            })
        }
        else if (gameState == .salt) {
            Assets.salt.texture = SKTexture(imageNamed: "salt1")
            Assets.lid.texture = SKTexture(imageNamed: "lid")
        }
        else if (gameState == .pasta) {
            Assets.salt.texture = SKTexture(imageNamed: "salt")
            Assets.pasta.texture = SKTexture(imageNamed: "pasta55")
        }
        else if (gameState == .turnOffFire) {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                Assets.miniButton.texture = SKTexture(imageNamed: "minibutton1")
            })
        }
        else if (gameState == .colander) {
            Assets.miniButton.texture = SKTexture(imageNamed: "minibutton")
            Assets.colander.texture = SKTexture(imageNamed: "colander1")
        }
        else if (gameState == .drainWater) {
            Assets.pot.texture = SKTexture(imageNamed: "potW")
            Assets.colander.texture = SKTexture(imageNamed: "colander")
        }
        else if (gameState == .drainWater2) {
            Assets.colander.texture = SKTexture(imageNamed: "colander1")
        }
        else if (gameState == .tomato) {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                
                Assets.pan.texture = SKTexture(imageNamed: "pan3")
                Assets.colander.texture = SKTexture(imageNamed: "colander")
            })
        }
        else if (gameState == .end) {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                Assets.plate.texture = SKTexture(imageNamed: "plate1")
            })
        }
    }
    
    func setUp(node: SKNode, addIn parent: SKNode? = nil, at position: CGPoint, withZ zPosition: CGFloat = Z.background, andHidden hidden: Bool = false) {
        node.position = position
        node.zPosition = zPosition
        node.isHidden = hidden
        if let parent = parent {
            parent.addChild(node)
        } else {
            addChild(node)
        }
    }
    
    public override func didMove(to view: SKView) {
        setUp(node: Assets.background, at: CGPoint(x: frame.midX, y: frame.midY))
        setUp(node: Assets.pot, at: CGPoint(x: 1130, y: 820), withZ: Z.z2)
        setUp(node: Assets.background2, at: CGPoint(x: frame.midX, y: 155), withZ: Z.z1)
        setUp(node: Assets.littleLid, at: CGPoint(x: 1130, y: 780), withZ: Z.z0, andHidden: true)
        setUp(node: Assets.potWW, at: CGPoint(x: 920, y: 495), withZ: Z.z2, andHidden: true)
        setUp(node: Assets.lid, at: CGPoint(x: 800, y: 800), withZ: Z.z1)
        setUp(node: Assets.pan, at: CGPoint(x: 486, y: 371), withZ: Z.z2)
        setUp(node: Assets.pan2, at: CGPoint(x: 196, y: 624), withZ: Z.z1, andHidden: true)
        setUp(node: Assets.pastaJar, at: CGPoint(x: 345, y: 747), withZ: Z.z2)
        setUp(node: Assets.button, at: CGPoint(x: 1180, y: 400), withZ: Z.z0)
        setUp(node: Assets.miniButton, at: CGPoint(x: 130, y: 192), withZ: Z.z3)
        setUp(node: Assets.fire, at: CGPoint(x: 185, y: 314), withZ: Z.z1, andHidden: true)
        setUp(node: Assets.water, at: CGPoint(x: 918, y: 482), withZ: Z.z0, andHidden: true)
        setUp(node: Assets.bubbles, at: CGPoint(x: 192, y: 360), withZ: Z.z3, andHidden: true)
        setUp(node: Assets.salt, at: CGPoint(x: 159, y: 729), withZ: Z.z0)
        setUp(node: Assets.colander, at: CGPoint(x: 250, y: 958), withZ: Z.z0)
        setUp(node: Assets.pasta, at: CGPoint(x: 340, y: 768), withZ: Z.z1)
        setUp(node: Assets.plate, at: CGPoint(x: 446, y: 773), withZ: Z.z1)
        setUp(node: Assets.pasta1, at: CGPoint(x: 200, y: 358), withZ: Z.z3, andHidden: true)
        setUp(node: Assets.explosionEmitter, addIn: Assets.bubbles, at: CGPoint(x: 0, y: 0), withZ: Z.z0)
        setUp(node: Assets.saltParticle, addIn: Assets.salt, at: CGPoint(x: 0, y: 0), withZ: Z.z0, andHidden: true)
        setUp(node: Assets.explotionEmitter, addIn: Assets.pasta1, at: CGPoint(x: 3, y: -45), withZ: Z.z5, andHidden: true)
        light()
        addChild(Assets.backgroundMusic)
    }
    public func goToScene() {
        let finalScene = FinalScene(size: frame.size)
        if Assets.plate.contains(touchLocation) && gameState == .end {
            if let view = view {
                
                view.presentScene(finalScene, transition: SKTransition.fade(withDuration: TimeInterval(2.5)))
            }
        }
    }
}
