import Foundation
import PlaygroundSupport
import SpriteKit

public class FinalScene: SKScene {
    var touchLocation = CGPoint()
    var gameState: GameState = .end
    
    public override init(size: CGSize) {
        super.init(size: size)
        /* Set the scale mode to scale to fit the window */
        scaleMode = .aspectFit
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("")
    }
    func garnish () {
        if ((Assets.basil.contains(touchLocation) || Assets.basilLeaves.contains(touchLocation)) && gameState == .end1) {
            Assets.basilLeaves.position.x = touchLocation.x
            Assets.basilLeaves.position.y = touchLocation.y
            
            if (Assets.basilLeaves.position.y < 600.0 && Assets.basilLeaves.position.x < 300 && Assets.basilLeaves.position.x > 100) {
                Assets.basilLeaves.position.x = 196
                Assets.basilLeaves.position.y = 390
                addChild(Assets.tada)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.3, execute: {
                    Assets.tada.removeFromParent()
                    
                })
                
                gameState = .realEnd
            }
        }
    }
                
    func garnish1 () {
        if (Assets.pan1.contains(touchLocation) && gameState == .end) {
            Assets.pan1.position.x = touchLocation.x
            Assets.pan1.position.y = touchLocation.y
            
            if (Assets.pan1.position.y < 600.0 && Assets.pan1.position.x < 300 && Assets.pan1.position.x > 100) {
                Assets.pan1.position.x = 196
                Assets.pan1.position.y = 624
                Assets.pan1.addChild(Assets.sauce)
                
                Assets.pan1.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                Assets.sauce.run(SKAction.rotate(toAngle: -CGFloat.pi, duration: 0.1))
                
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.3, execute: {
                    self.addChild(Assets.sauceAudio)
                    Assets.topping.isHidden = false
                })
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0, execute: {
                    Assets.pan1.run(SKAction.rotate(toAngle: 0, duration: 0.1))
                    Assets.sauce.removeFromParent()
                    Assets.pan1.position.x = 730
                    Assets.pan1.position.y = 300
                    Assets.sauceAudio.removeFromParent()
                    
                    
                })
                gameState = .end1
            }
        }
            
        }
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        garnish1()
        garnish()
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            (touchLocation = touch.location(in: self))
            garnish1()
            garnish()
        }
    }
    func setUp(node: SKNode, addIn parent: SKNode? = nil, at position: CGPoint, withZ zPosition: CGFloat = Z.background, andHidden hidden: Bool = false) {
        node.position = position
        node.zPosition = zPosition
        node.isHidden = hidden
        if let parent = parent {
            parent.addChild(node)
        } else {
            addChild(node)
        }
    }
    
    public override func didMove(to view: SKView) {
        setUp(node: Assets.finalScene, at: CGPoint(x: frame.midX, y: frame.midY), withZ: Z.background)
        setUp(node: Assets.basil, at: CGPoint(x: 1130, y: 161 + 282), withZ: Z.z2)
        setUp(node: Assets.basilLeaves, at: CGPoint(x: 1130, y: 161 + 282), withZ: Z.z4)
        setUp(node: Assets.plate1, at: CGPoint(x: 195, y: 161 + 142), withZ: Z.z3)
        setUp(node: Assets.pan1, at: CGPoint(x: 730, y: 300), withZ: Z.z0)
        setUp(node: Assets.pasta2, at: CGPoint(x: 195, y: 350), withZ: Z.z1)
        setUp(node: Assets.topping, at: CGPoint(x: 190, y: 374), withZ: Z.z3, andHidden: true)
        Assets.pasta2.run(SKAction.colorize(with: .red, colorBlendFactor: 0.2, duration: 0))
   
    }
    
    
}
