import Foundation
import SpriteKit


public enum Assets {
    
    public static let sceneView = SKView(frame: UIScreen.main.bounds)
    public static let litFireAudio = SKAudioNode(fileNamed: "lit fire.mp3")
    public static let saltAudio = SKAudioNode(fileNamed: "salting.mp3")
    public static let backgroundMusic = SKAudioNode(fileNamed: "backgroundMusic.mp3")
    public static let waterBoilingAudio = SKAudioNode(fileNamed: "boilingWater.mp3")
    public static let waterBoilingAudio2 = SKAudioNode(fileNamed: "123.mp3")
    public static let tada = SKAudioNode(fileNamed: "tada.mp3")
    public static let potOnIronAudio = SKAudioNode(fileNamed: "pot on iron.mp3")
    public static let sauceAudio = SKAudioNode(fileNamed: "sauce.mp3")
    public static let waterSinkAudio = SKAudioNode(fileNamed: "water sink.mp3")
    public static let drainingWaterAudio = SKAudioNode(fileNamed: "draining water.mp3")
    public static let explotionEmitter: SKEmitterNode = SKEmitterNode(fileNamed: ("water.sks"))!
    public static let sauce: SKEmitterNode = SKEmitterNode(fileNamed: ("sauce.sks"))!
    public static let explosionEmitter: SKEmitterNode = SKEmitterNode(fileNamed: ("bubbles.sks"))!
    public static let steam: SKEmitterNode = SKEmitterNode(fileNamed: ("steam.sks"))!
    public static let saltParticle: SKEmitterNode = SKEmitterNode(fileNamed: ("faber2.sks"))!
    public static let fire: SKEmitterNode = SKEmitterNode(fileNamed: ("fire.sks"))!
    public static let background = SKSpriteNode(texture: SKTexture(imageNamed: "bg"), size: CGSize(width: 1366, height: 1024))
    public static let firstSceneBackground = SKSpriteNode(texture: SKTexture(imageNamed: "firstSceneBackground"), size: CGSize(width: 1366, height: 1024))
    public static let finalScene = SKSpriteNode(texture: SKTexture(imageNamed: "final scene"), size: CGSize(width: 1366, height: 1024))
    public static let plate1 = SKSpriteNode(texture: SKTexture(imageNamed: "final plate"), size: CGSize(width: 428 / 2, height: 124 / 2))
    public static let basilLeaves = SKSpriteNode(texture: SKTexture(imageNamed: "basil leaves"), size: CGSize(width: 58, height: 54))
    public static let basil = SKSpriteNode(texture: SKTexture(imageNamed: "basil"), size: CGSize(width: 236, height: 346))
    public static let topping = SKSpriteNode(texture: SKTexture(imageNamed: "topping"), size: CGSize(width: 230, height: 81))
    public static let background2 = SKSpriteNode(texture: SKTexture(imageNamed: "background2"), size: CGSize(width: 1366, height: 387))
    public static let miniButton = SKSpriteNode(texture: SKTexture(imageNamed: "minibutton"), size: CGSize(width: 50 / 2  , height: 54  ))
    public static let bubbles = SKSpriteNode(texture: SKTexture(imageNamed: "bubbles.png"), size: CGSize(width: 408 / 3 , height: 180 / 3))
    public static let pan2 = SKSpriteNode(texture: SKTexture(imageNamed: "pan 2.png"), size: CGSize(width: 326 , height: 107 / 1.5))
    public static let pan1 = SKSpriteNode(texture: SKTexture(imageNamed: "pan 2.png"), size: CGSize(width: 326 , height: 107 / 1.5))
    public static let button = SKSpriteNode(texture: SKTexture(imageNamed: "waterButton.png"), size: CGSize(width: 142  , height: 196))
    public static let water = SKSpriteNode(texture: SKTexture(imageNamed: "water.png"), size: CGSize(width: 22 / 2 , height: 176))
    public static let pot = SKSpriteNode(texture: SKTexture(imageNamed: "pot.png"), size: CGSize(width: 408 / 1.5 , height: 195 / 1.5 ))
    public static let plate = SKSpriteNode(texture: SKTexture(imageNamed: "plate.png"), size: CGSize(width: 115 / 1.5 , height: 204 ))
    public static let potWW = SKSpriteNode(texture: SKTexture(imageNamed: "potWW.png"), size: CGSize(width: 408 / 1.5 , height: 331 ))
    public static let lid = SKSpriteNode(texture: SKTexture(imageNamed: "lid.png"), size: CGSize(width: 312 / 1.5, height: 136 / 1.5))
    public static let littleLid = SKSpriteNode(texture: SKTexture(imageNamed: "littleLid.png"), size: CGSize(width: 312 / 1.5, height: 86 / 1.5))
    public static let pan = SKSpriteNode(texture: SKTexture(imageNamed: "pan.png"), size: CGSize(width: 326 , height: 157 / 1.5))
    public static let pastaJar = SKSpriteNode(texture: SKTexture(imageNamed: "pastaJar.png"), size: CGSize(width: 158 , height: 166 / 1))
    public static let pasta = SKSpriteNode(texture: SKTexture(imageNamed: "pasta.png"), size: CGSize(width: 150, height: 198 ))
    public static let pasta1 = SKSpriteNode(texture: SKTexture(imageNamed: "pasta1.png"), size: CGSize(width: 194, height: 108))
    public static let pasta2 = SKSpriteNode(texture: SKTexture(imageNamed: "pasta1.png"), size: CGSize(width: 194, height: 108))
    public static let salt = SKSpriteNode(texture: SKTexture(imageNamed: "salt.png"), size: CGSize(width:110 / 1.2, height: 148 / 1.2 ))
    public static let colander = SKSpriteNode(texture: SKTexture(imageNamed: "colander.png"), size: CGSize(width: 329, height: 124))
}

public enum Z {
    public static let background: CGFloat = -1.0
    public static let z0: CGFloat = 0.0
    public static let z1: CGFloat = 1.0
    public static let z2: CGFloat = 2.0
    public static let z3: CGFloat = 3.0
    public static let z4: CGFloat = 4.0
    public static let z5: CGFloat = -4.0
}


public enum GameState {
    case pot
    case water
    case potWW
    case litFire
    case lid
    case boiling
    case salt
    case pasta
    case removeLid
    case turnOffFire
    case colander
    case drainWater
    case tomato
    case drainWater2
    case animation
    case animation1
    case end
    case end1
    case realEnd
}
