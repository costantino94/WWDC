import Foundation
import PlaygroundSupport
import SpriteKit

public class FirstScene: SKScene {
    var touchLocation = CGPoint()
    var gameState: GameState = .pot
    
    public override init(size: CGSize) {
        super.init(size: size)
        /* Set the scale mode to scale to fit the window */
        scaleMode = .aspectFit
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("")
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        goToScene()
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            touchLocation = touch.location(in: self)
        }
    }
    
    public override func didMove(to view: SKView) {
        Assets.firstSceneBackground.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(Assets.firstSceneBackground)
    }
    
    public func goToScene() {
        let scene = GameScene(size: frame.size)
        if let view = view {
            view.presentScene(scene, transition: SKTransition.fade(withDuration: TimeInterval(2.5)))
        }
    }
}

